### 1.0.2

* Fixed EPEL issue under CentOS 7.0

### 1.0.1

* Requires Ansible 1.9 (haven't tested on earlier versions)

### 1.0.0

* First initial release
